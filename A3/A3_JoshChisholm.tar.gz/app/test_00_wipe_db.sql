delete from recordings;
delete from songs;
delete from tracks;
delete from users;
delete from playlists;
delete from playlist_tracks;
