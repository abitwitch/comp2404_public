//Author: Josh Chisholm (100770668)
//file: sharedFunctions.h
#ifndef SHAREDFUNCTIONS_H
#define SHAREDFUNCTIONS_H

#include <iostream>
#include <string>
using namespace std;

string toTitleCase(string inStr);

#endif
