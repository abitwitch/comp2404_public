#include<iostream>
#include <fstream>
#include <string>
#include <vector>

#include "fileobj.h"

using namespace std;

//Global variables
bool logCmds=false;
bool logOuts=false;
string logFileName="testlog.txt";

struct LogStream
{
    template<typename T> LogStream& operator<<(const T& mValue)
    {
        cout << mValue;
        if(logOuts){
          ofstream myfile;
          myfile.open (logFileName, std::ios::app);
          if(!myfile){
        		cout << "ERROR: could not open file " << logFileName << "\n";
        	} else{
            myfile << mValue;
          }
          myfile.close();
        }
        //someLogStream << mValue;
    }
};

inline LogStream& lo() { static LogStream l; return l; }


string trim(string &input, bool trimInsideString){
  size_t start=input.find_first_not_of(" \t");
  size_t end=input.find_last_not_of(" \t");
  if(string::npos==start){
    return input;
  }
  input=input.substr(start,(end-start+1));
  if (trimInsideString){
    string tempStrHolder="";
    char prevChar=input[0];
    for (auto& iter : input){
      if(prevChar==' '&&iter==' '){
        //skip all subsiquent spaces
      }else{
        tempStrHolder.push_back(iter);
      }
      prevChar=iter;
    }
    input=tempStrHolder;
  }
  return input;
}

vector<string> parse(string input){
  vector<string> args;
  bool inStr=false;
  int index=0;
  int startIndex=0;
  int argLength=0;
  for (auto& iter : input){
    if (iter=='"'){
      inStr=!inStr;
    }
    if (!inStr){
      if (iter==' '){
        args.push_back(input.substr(startIndex,argLength));
        startIndex=index+1;
        argLength=-1;
      }
      if (index+1==input.length()){
        args.push_back(input.substr(startIndex,argLength+1));
        startIndex=index+1;
        argLength=-1;
      }
    }
    index++;
    argLength++;
  }
  if (inStr){
    lo() << "Invalid input detected: " << input << "\n";
  }
  return args;
}

void printVectorStr (vector<string> args){
  lo() << "Parsed command arguments:\n";
  vector<string>::iterator i;
  for (i=args.begin();i<args.end();i++){
    lo() << "  -" << *i <<"\n";
  }
}

bool startsWith(string fullStr, string prefix){
  fullStr=fullStr.substr(1,fullStr.length()-2);//remove quotes from string
  prefix=prefix.substr(1,prefix.length()-2);//remove quotes from string
  if(fullStr.length()<prefix.length()){
    return false;
  }
  if(fullStr.substr(0,prefix.length())==prefix){
    return true;
  } else {
    return false;
  }
}
bool endsWith(string fullStr, string prefix){
  fullStr=fullStr.substr(1,fullStr.length()-2);//remove quotes from string
  prefix=prefix.substr(1,prefix.length()-2);//remove quotes from string
  if(fullStr.length()<prefix.length()){
    return false;
  }
  if(fullStr.substr(fullStr.length()-prefix.length(),prefix.length())==prefix){
    return true;
  } else {
    return false;
  }
}

string toTitleCase(string inStr){
  if(inStr[0]=='"' && inStr.back()=='"'){
    inStr=inStr.substr(1,inStr.length()-2);//remove quotes from string
  }
  string outStr="";
  char prevChar=' ';//add space a beginning so first word isn't special case
  for (auto& iter : inStr){
    if((iter>='a' && iter<='z')&&prevChar==' '){
      outStr.push_back(toupper(iter));
    } else if((iter>='A' && iter<='Z')&&prevChar!=' ') {
      outStr.push_back(tolower(iter));
    } else {
      outStr.push_back(iter);
    }
    prevChar=iter;
  }
  return outStr;
}

void updateLogging(string updateCmd, string newLogFileName){
  if(updateCmd=="clear"){
    ofstream myfile;
    myfile.open (logFileName);
    myfile.close();
    lo() << "Log file cleared.\n";
  } else if (updateCmd=="start"){
    logCmds=true;
    logOuts=false;
    lo() << "Started logging all commands.\n";
  } else if (updateCmd=="start_output"){
    logCmds=false;
    logOuts=true;
    lo() << "Started logging all outputs.\n";
  } else if (updateCmd=="start_both"){
    logCmds=true;
    logOuts=true;
    lo() << "Started logging all commands and outputs.\n";
  } else if (updateCmd=="stop"){
    logCmds=false;
    logOuts=false;
    lo() << "Stopped all logging.\n";
  } else if (updateCmd=="save"){
    logFileName=newLogFileName;
    lo() << "Log file set to: " << newLogFileName << "\n";
  } else if (updateCmd=="show"){
    cout << "Contents of log file (this will not be logged in log file): " << newLogFileName << "\n";
    cout << "=-=-=-=-=-=-=-=-=-=-=-=-=-Start of file-=-=-=-=-=-=-=-=-=-=-=-=-=\n";
    FileObj file(logFileName);
    cout << file.read();
    cout << "=-=-=-=-=-=-=-=-=-=-=-=-=-=End of file=-=-=-=-=-=-=-=-=-=-=-=-=-=\n";
  } else {
    lo() << "Unknown argument for .log command: \"" << updateCmd << "\"\n";
    lo() << "type .help for help.\n";
  }

}



int main(void){
  //Welcome
  string welcomeStr=R"(
  +========================================+
  |                                        |
  |           Welcome to jTunes            |
  |                                        |
  +========================================+
  |  '>>>' is prompting you for a command  |
  |  At any time you can type:             |
  |    -> '.help' for help                 |
  |    -> '.quit' to quit                  |
  +========================================+)";
  lo() << welcomeStr << "\n\n";


  //Testing area

  //Testing area


  //Local variables
  string input;

  while(input!=".quit"){
    //=====get user input:=====
    if(logCmds){
      lo() << ">>>";
    } else {
      cout << ">>>";
    }
    getline(cin, input);
    if(logCmds){
      ofstream myfile;
      myfile.open (logFileName, std::ios::app);
      if(!myfile){
        cout << "ERROR: could not open file " << logFileName << "\n";
      } else{
        myfile << input << "\n";
      }
      myfile.close();
    }
    //=====clean up user input:=====
    bool trimInsideString=true;
    trim(input, trimInsideString);
    //TODO remove case sensitivity?
    //=====skip for empty input:=====
    if(input==""){
      continue;
    }
    //=====parse user input:=====
    vector<string> args=parse(input);
    printVectorStr(args);

    if (args[0].length()!=0 && input.at(0)=='.'){
      //=====pull out UI SHELL COMMANDS (start with a dot):=====
      if (input==".quit"){
        //-----quit-----
        lo() << "Exiting program. Goodbye!";
        continue; //the while loop will exit with ".quit"
      } else if (args[0]==".read") {
        //-----read-----
        FileObj file(args[1]);
        lo() << "=-=-=-=-=-=-=-=-=-=-=-=-=-Start of file-=-=-=-=-=-=-=-=-=-=-=-=-=\n";
        lo() << file.read();
        lo() << "=-=-=-=-=-=-=-=-=-=-=-=-=-=End of file=-=-=-=-=-=-=-=-=-=-=-=-=-=\n";
      } else if (args[0]==".log") {
        //-----log-----
        string logFileName="";
        if (args.size()>2){
          logFileName=args[2];
        }
        updateLogging(args[1],logFileName);
      } else if (input==".help") {
        //-----help-----
        FileObj file("help.txt");
        lo() << file.read();
      }
      //=====Developer commands:=====
      else if (args[0]==".trim") {
        //-----trim-----
        string args1_noQuotes=args[1].substr(1,args[1].length()-2);//remove quotes from string
        lo() << trim(args1_noQuotes,true) << "\n";
      } else if (args[0]==".startsWith") {
        //-----startsWith-----
        if(startsWith(args[1],args[2])){
          lo() << "true\n";
        } else {
          lo() << "false\n";
        }
      } else if (args[0]==".endsWith") {
        //-----endsWith-----
        if(endsWith(args[1],args[2])){
          lo() << "true\n";
        } else {
          lo() << "false\n";
        }
      } else if (args[0]==".toTitleCase") {
        //-----toTitleCase-----
        lo() << toTitleCase(args[1]) << "\n";
      }
      //=====Unknown UI Shell Command (start with a dot):=====
      else {
        lo() << "Unknown UI Shell Command: \"" << input << "\"\n";
        lo() << "type .help for help.\n";
      }
    } else {
      if (args[0]==".add") {
        lo() << "Not implemented yet: add\n";
      } else if (args[0]==".delete") {
        lo() << "Not implemented yet: delete\n";
      } else if (args[0]==".show") {
        lo() << "Not implemented yet: show\n";
      } else {
        //=====Unknown Command:=====
        lo() << "Unknown Command: \"" << input << "\"\n";
        lo() << "type .help for help.\n";
      }
    }

  }

  lo() << "\n";
  return 0;
}
